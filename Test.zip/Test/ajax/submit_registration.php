<?php
require_once '../controller/StudentController.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $course = $_POST['course'];
    $grade = $_POST['grade'];
    $contact = $_POST['contact'];
    $comments = $_POST['comments'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  

    $controller = new StudentController();
    $response = $controller->registerStudent($name, $email, $age, $course, $grade, $contact, $comments, $password);
    
    echo $response;
}
?>
