$(document).ready(function() {
     // alert("here");
     $('#registration-form').on('submit', function(e) {
          e.preventDefault();
 
         $.ajax({
             url: 'ajax/submit_registration.php',
             type: 'POST',
             data: $(this).serialize(),
             success: function(response) {
                 alert(response);
                 $('#registration-form')[0].reset();  
                 if (response.includes("successful")) {
                    window.location.href = 'view/login.php';
                }
             },
             error: function(xhr, status, error) {
                 alert('An error occurred: ' + error);
             }
         });
     });

     $('#login-form').on('submit', function(e) {
          e.preventDefault();  // Prevent form submission

          $.ajax({
              url: '/Test/ajax/login.php',
              type: 'POST',
              data: $(this).serialize(),
              success: function(response) {
                  if (response === 'Login successful') {
                      window.location.href = 'dashboard.php';  // Redirect to dashboard
                  } else {
                      $('#login-message').html('<div class="alert alert-danger">' + response + '</div>');
                  }
              },
              error: function(xhr, status, error) {
                  $('#login-message').html('<div class="alert alert-danger">An error occurred: ' + error + '</div>');
              }
          });
      });
 });
 