<?php
require_once '../model/Database.php';

class StudentController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function registerStudent($name, $email, $age, $course, $grade, $contact, $comments, $password) {
        try {
            $query = "INSERT INTO students (name, email, age, course, grade, contact, comments, password) VALUES (:name, :email, :age, :course, :grade, :contact, :comments, :password)";
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':age', $age);
            $stmt->bindParam(':course', $course);
            $stmt->bindParam(':grade', $grade);
            $stmt->bindParam(':contact', $contact);
            $stmt->bindParam(':comments', $comments);
            $stmt->bindParam(':password', $password);
            
            if ($stmt->execute()) {
                return "Registration successful!";
            } else {
                return "Registration failed!";
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function loginStudent($email) {
     try {
         $query = "SELECT * FROM students WHERE email = :email LIMIT 1";
         $stmt = $this->conn->prepare($query);
         $stmt->bindParam(':email', $email);
         $stmt->execute();
         
         return $stmt->fetch(PDO::FETCH_ASSOC); 
     } catch (PDOException $e) {
         return false;
     }
     }
     public function getStudentById($user_id) {
     
     
          $stmt =  $this->conn->prepare("SELECT * FROM students WHERE id = ?");
          $stmt->execute([$user_id]);
          return $stmt->fetch(PDO::FETCH_ASSOC);
      }
  
      public function updateStudentProfile($user_id, $name, $age, $course,$grade,$contact,$comments = null) {

          $stmt = $this->conn->prepare("UPDATE students SET name = ?, age = ?, course = ?, grade = ?, contact = ?, comments = ? WHERE id = ?");
          return $stmt->execute([$name, $age, $course, $grade, $contact, $comments, $user_id]);
      }
}
?>
