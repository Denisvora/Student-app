<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

echo "<h1>Welcome to the Dashboard!</h1>";
echo "<p>Your user ID is: " . $_SESSION['user_id'] . "</p>";
echo "<p>Your name is: " . $_SESSION['user_name'] . "</p>";
echo "<p>Your email is: " . $_SESSION['user_email'] . "</p>";

echo '<a href="profile.php" class="btn btn-danger">Profile</a> </br>';

echo '<a href="logout.php" class="btn btn-danger">Logout</a>';
?>
